# 桌面宠物生成器

这是精简版：已删除用于双击启动服务器的 bat 文件。你可以自己用 CMD / PowerShell 启动服务器。

## 启动方式

1. 进入本项目根目录，也就是能看到 `package.json` 的文件夹。
2. 在地址栏输入 `cmd` 并回车，或右键选择“在终端中打开”。
3. 第一次使用先安装依赖：

```bash
npm install
```

4. 启动服务器：

```bash
npm start
```

5. 浏览器打开终端中显示的地址，通常是：

```text
http://localhost:3000
```

如果 3000 被占用，程序会自动尝试 3001、3002 等端口，请以终端显示的地址为准。

## 项目结构

```text
package.json
server/                 后端服务和生成 zip 逻辑
public/                 网页前端
  index.html
  app.js
  style.css
templates/
  windows-pet-template/ Windows 桌面宠物模板
```

## 使用注意

- 使用期间不要关闭运行 `npm start` 的终端窗口。
- 网页必须从 `http://localhost:端口` 打开，不要直接双击 `public/index.html`。
- 生成出来的 Windows 桌面宠物 zip 解压后，双击里面的 `start-pet.bat` 运行。

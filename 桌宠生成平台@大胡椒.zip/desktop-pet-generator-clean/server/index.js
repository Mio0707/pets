const express = require('express');
const path = require('path');
const fs = require('fs-extra');
const multer = require('multer');
const archiver = require('archiver');

const app = express();

process.on('uncaughtException', (err) => {
  console.error('[未捕获异常]', err && (err.stack || err.message) || err);
});
process.on('unhandledRejection', (err) => {
  console.error('[未处理 Promise 异常]', err && (err.stack || err.message) || err);
});
const START_PORT = Number(process.env.PORT || 3000);
const HOST = '127.0.0.1';

const ROOT = path.join(__dirname, '..');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const GENERATED_DIR = path.join(ROOT, 'generated');
const TEMPLATE_DIR = path.join(ROOT, 'templates', 'windows-pet-template');

fs.ensureDirSync(UPLOAD_DIR);
fs.ensureDirSync(GENERATED_DIR);

const TRIGGER_FIELDS = ['rest', 'hover', 'click', 'doubleClick'];

const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    await fs.ensureDir(UPLOAD_DIR);
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.png';
    const safeBase = path.basename(file.originalname || 'image', ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    cb(null, `${Date.now()}_${Math.random().toString(16).slice(2)}_${safeBase}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
    if (!allowed.includes(file.mimetype)) return cb(new Error('只支持 PNG、JPG、WEBP、GIF 图片'));
    cb(null, true);
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(ROOT, 'public')));
app.use('/generated', express.static(GENERATED_DIR));

function clampNumber(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function normalizeText(value, fallback, maxLength = 80) {
  const text = String(value || '').trim();
  if (!text) return fallback;
  return text.slice(0, maxLength);
}

function fileByField(files, field) {
  return (files || []).find((f) => f.fieldname === field);
}

function safeFileBase(name, fallback) {
  const text = String(name || '').trim() || fallback;
  return text.replace(/[^a-zA-Z0-9_\-\u4e00-\u9fa5]/g, '_').slice(0, 40) || fallback;
}

function parseStates(raw) {
  let parsed = [];
  try {
    parsed = JSON.parse(raw || '[]');
  } catch {
    parsed = [];
  }

  const seen = new Set();
  const states = [];
  for (const item of Array.isArray(parsed) ? parsed : []) {
    const name = String(item?.name || '').trim().replace(/\s+/g, '_').slice(0, 32);
    const index = Number(item?.index);
    if (!name || !Number.isInteger(index) || seen.has(name)) continue;
    seen.add(name);
    states.push({ name, index });
  }
  return states;
}

function parseInteractions(raw, validActions) {
  let parsed = {};
  try {
    parsed = JSON.parse(raw || '{}');
  } catch {
    parsed = {};
  }

  const fallback = {
    rest: [{ action: 'rest', text: '我休息一下～' }],
    hover: [{ action: 'wave', text: '嗨！' }],
    click: [{ action: 'happy', text: '嘿嘿！' }],
    doubleClick: [{ action: 'talk', text: '你双击我啦！' }]
  };

  const result = {};
  for (const trigger of TRIGGER_FIELDS) {
    const rows = Array.isArray(parsed[trigger]) ? parsed[trigger] : fallback[trigger];
    result[trigger] = rows
      .map((row) => {
        const action = String(row?.action || '').trim();
        return {
          action: validActions.includes(action) ? action : (validActions[0] || 'idle'),
          text: normalizeText(row?.text, '', 120)
        };
      })
      .filter((row) => row.action);

    if (!result[trigger].length) result[trigger] = fallback[trigger];
  }
  return result;
}

async function zipDirectory(sourceDir, outPath) {
  await fs.ensureDir(path.dirname(outPath));
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve());
    archive.on('error', reject);

    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
  });
}

app.post('/api/generate', (req, res) => {
  upload.any()(req, res, async (uploadError) => {
    if (uploadError) {
      console.error('[上传失败]', uploadError);
      return res.status(400).json({ message: uploadError.message || '上传失败，请检查图片大小和格式。' });
    }
    try {
    const files = Array.isArray(req.files) ? req.files : Object.values(req.files || {}).flat();
    const states = parseStates(req.body.statesJson);
    if (!states.length) {
      return res.status(400).json({ message: '请至少添加并上传 idle 默认状态图片。' });
    }
    if (!states.some((state) => state.name === 'idle')) {
      return res.status(400).json({ message: '请保留 idle 默认状态。' });
    }
    const idleState = states.find((state) => state.name === 'idle');
    const idle = fileByField(files, `stateImage_${idleState.index}`);
    if (!idle) {
      return res.status(400).json({ message: '请至少上传 idle 默认状态图片。' });
    }

    const packageId = `${Date.now()}_${Math.random().toString(16).slice(2)}`;
    const outputDir = path.join(GENERATED_DIR, packageId, 'desktop-pet');
    const assetsDir = path.join(outputDir, 'assets');
    const zipPath = path.join(GENERATED_DIR, `${packageId}.zip`);

    await fs.copy(TEMPLATE_DIR, outputDir);
    await fs.emptyDir(assetsDir);

    const actions = {};
    for (const state of states) {
      const file = fileByField(files, `stateImage_${state.index}`);
      if (!file) continue;
      const ext = path.extname(file.originalname || '.png').toLowerCase() || '.png';
      const targetName = `${safeFileBase(state.name, 'state')}${ext}`;
      await fs.copy(file.path, path.join(assetsDir, targetName));
      actions[state.name] = `assets/${targetName}`;
    }

    if (!actions.idle) actions.idle = `assets/${path.basename(idle.filename || idle.path)}`;
    for (const state of states) {
      if (!actions[state.name]) actions[state.name] = actions.idle;
    }

    const width = clampNumber(req.body.width, 120, 40, 600);
    const height = clampNumber(req.body.height, 140, 40, 700);
    const bubbleEnabled = req.body.bubbleEnabled === 'true' || req.body.bubbleEnabled === 'on';
    const bubbleText = normalizeText(req.body.bubbleText, '你好呀！', 120);
    const petName = normalizeText(req.body.petName, '我的桌面宠物', 40);
    const restDelayMinutes = clampNumber(req.body.restDelayMinutes ?? req.body.restDelaySeconds, 8, 1, 240);
    const actionNames = Object.keys(actions);
    const interactions = parseInteractions(req.body.interactionsJson, actionNames);

    const allBubbleTexts = [bubbleText];
    Object.values(interactions).forEach((rows) => {
      rows.forEach((row) => allBubbleTexts.push(row.text || ''));
    });
    const longestBubbleText = allBubbleTexts.reduce((max, text) => Math.max(max, String(text || '').length), 0);
    const textBasedWindowWidth = Math.min(460, Math.max(220, longestBubbleText * 18 + 80));

    const config = {
      petName,
      width,
      height,
      windowWidth: bubbleEnabled ? Math.max(width + 120, textBasedWindowWidth, 260) : Math.max(width + 40, 180),
      windowHeight: Math.max(height + (bubbleEnabled ? 88 : 28), height + 28),
      defaultAction: actionNames.includes(req.body.defaultAction) ? req.body.defaultAction : 'idle',
      hoverAction: interactions.hover[0]?.action || 'idle',
      clickAction: interactions.click[0]?.action || 'idle',
      doubleClickAction: interactions.doubleClick[0]?.action || 'idle',
      restAction: interactions.rest[0]?.action || 'idle',
      bubbleEnabled,
      bubbleText,
      bubblePosition: 'top',
      restDelayMs: restDelayMinutes * 60 * 1000,
      idleAfterInteractionMs: 60 * 1000,
      actionDurationMs: 1100,
      bubbleDisplayMs: 3000,
      alwaysOnTop: true,
      draggable: true,
      actions,
      interactions
    };

    await fs.writeJson(path.join(outputDir, 'config.json'), config, { spaces: 2 });

    const readme = `# ${petName}\n\n使用方式：\n\n1. 解压这个 zip。\n2. 双击 start-pet.bat。\n3. 鼠标悬停、点击、双击会从你设置的互动里随机出现；任意交互后先进入 1 分钟待机，再回到休息。\n4. 休息状态下，每隔你设置的休息间隔会随机切换一次休息状态；拖动宠物可以移动位置。\n5. 右键宠物窗口或按 ESC 可以关闭。\n\n如果 Windows 提示是否允许运行脚本，请选择允许。\n`;
    await fs.writeFile(path.join(outputDir, 'README.txt'), readme, 'utf8');

    await zipDirectory(outputDir, zipPath);

    res.json({
      message: '生成成功',
      downloadUrl: `/generated/${packageId}.zip`,
      config
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message || '生成失败' });
    }
  });
});


app.get('/health', (req, res) => {
  res.json({ ok: true });
});

function listenWithFallback(port, maxPort = port + 20) {
  const server = app.listen(port, HOST, async () => {
    const url = `http://${HOST}:${port}`;
    const rootUrl = `http://localhost:${port}`;
    await fs.writeFile(path.join(ROOT, '.current-url.txt'), rootUrl, 'utf8').catch(() => {});
    console.log('');
    console.log('==================================================');
    console.log(`桌面宠物生成器已启动：${rootUrl}`);
    console.log(`如果打不开，也可以试试：${url}`);
    console.log('请保持这个黑色窗口不要关闭。');
    console.log('==================================================');
    console.log('');
  });

  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && port < maxPort) {
      console.log(`端口 ${port} 被占用，正在尝试 ${port + 1}...`);
      listenWithFallback(port + 1, maxPort);
      return;
    }
    console.error('启动失败：', err.message || err);
    console.error('请检查 Node.js、端口占用或防火墙设置。');
    process.exit(1);
  });
}

listenWithFallback(START_PORT);


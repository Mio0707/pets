const form = document.getElementById('petForm');
const preview = document.getElementById('petPreview');
const bubble = document.getElementById('bubble');
const statusEl = document.getElementById('status');
const downloadLink = document.getElementById('downloadLink');
const generateBtn = document.getElementById('generateBtn');
const interactionEditor = document.getElementById('interactionEditor');
const stateEditor = document.getElementById('stateEditor');
const addStateBtn = document.getElementById('addStateBtn');
const defaultActionSelect = document.getElementById('defaultActionSelect');

const triggers = [
  { key: 'rest', title: '休息', hint: '没有交互时显示休息状态；每隔设定分钟数随机切换一次。' },
  { key: 'hover', title: '悬停', hint: '鼠标移到宠物身上时触发。' },
  { key: 'click', title: '点击', hint: '单击宠物时触发。' },
  { key: 'doubleClick', title: '双击', hint: '双击宠物时触发。' }
];

const defaultStates = [
  { name: 'idle', label: '默认 idle *', required: true },
  { name: 'rest', label: '休息 rest' },
  { name: 'wave', label: '悬停 wave' },
  { name: 'happy', label: '开心 happy' },
  { name: 'talk', label: '说话 talk' },
  { name: 'sad', label: '伤心 sad' }
];

const defaultInteractions = {
  rest: [
    { action: 'rest', text: '我休息一下～' },
    { action: 'idle', text: '发会儿呆。' }
  ],
  hover: [
    { action: 'wave', text: '嗨！' },
    { action: 'talk', text: '找我玩吗？' }
  ],
  click: [
    { action: 'happy', text: '嘿嘿！' },
    { action: 'wave', text: '我在这里！' }
  ],
  doubleClick: [
    { action: 'talk', text: '你双击我啦！' },
    { action: 'happy', text: '今天也要开心！' }
  ]
};

const objectUrls = new Map();
let restPreviewTimer = null;
let clickTimer = null;
let bubblePreviewTimer = null;
let customStateCount = 0;

function normalizeStateName(name) {
  return String(name || '').trim().replace(/\s+/g, '_').slice(0, 32);
}

function getStateRows() {
  return Array.from(stateEditor.querySelectorAll('.state-row'));
}

function getStatesFromDom() {
  const seen = new Set();
  const states = [];
  getStateRows().forEach((row, index) => {
    const nameInput = row.querySelector('.state-name-input');
    const fileInput = row.querySelector('.state-file-input');
    const rawName = normalizeStateName(nameInput.value);
    if (!rawName || seen.has(rawName)) return;
    seen.add(rawName);
    states.push({
      name: rawName,
      index,
      file: fileInput.files?.[0] || null,
      required: row.dataset.required === 'true'
    });
  });
  return states;
}

function getActionList() {
  const names = getStatesFromDom().map((state) => state.name);
  return names.length ? names : ['idle'];
}

function getImages() {
  const images = {};
  getStateRows().forEach((row) => {
    const name = normalizeStateName(row.querySelector('.state-name-input').value);
    const url = row.dataset.previewUrl;
    if (name && url) images[name] = url;
  });
  return images;
}

function updateStateOptions() {
  const actionList = getActionList();
  const oldDefault = defaultActionSelect.value || 'idle';
  defaultActionSelect.innerHTML = '';
  actionList.forEach((action) => {
    const option = document.createElement('option');
    option.value = action;
    option.textContent = action;
    defaultActionSelect.appendChild(option);
  });
  defaultActionSelect.value = actionList.includes(oldDefault) ? oldDefault : (actionList.includes('idle') ? 'idle' : actionList[0]);

  interactionEditor.querySelectorAll('.action-select').forEach((select) => {
    const oldValue = select.value;
    select.innerHTML = '';
    actionList.forEach((action) => {
      const option = document.createElement('option');
      option.value = action;
      option.textContent = action;
      select.appendChild(option);
    });
    select.value = actionList.includes(oldValue) ? oldValue : actionList[0];
  });
}

function setPreviewFromDefault() {
  const images = getImages();
  const defaultAction = defaultActionSelect.value || 'idle';
  preview.src = images[defaultAction] || images.idle || '';
}

function createStateRow(data = {}) {
  const row = document.createElement('div');
  row.className = 'state-row';
  row.dataset.required = data.required ? 'true' : 'false';

  const nameLabel = document.createElement('label');
  nameLabel.textContent = data.label || '状态名称';
  const nameInput = document.createElement('input');
  nameInput.className = 'state-name-input';
  nameInput.placeholder = '例如 sleep / eat / angry';
  nameInput.value = data.name || `custom_${++customStateCount}`;
  nameInput.maxLength = 32;
  if (data.required) nameInput.readOnly = true;
  nameLabel.appendChild(nameInput);

  const fileLabel = document.createElement('label');
  fileLabel.textContent = '状态图片';
  const fileInput = document.createElement('input');
  fileInput.className = 'state-file-input';
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  if (data.required) fileInput.required = true;
  fileLabel.appendChild(fileInput);

  const previewBox = document.createElement('div');
  previewBox.className = 'state-thumb empty';
  previewBox.textContent = '预览';

  const removeButton = document.createElement('button');
  removeButton.type = 'button';
  removeButton.className = 'mini-btn ghost';
  removeButton.textContent = data.required ? '必填' : '删除';
  removeButton.disabled = !!data.required;

  nameInput.addEventListener('input', () => {
    updateStateOptions();
    setPreviewFromDefault();
  });

  fileInput.addEventListener('change', () => {
    if (row.dataset.urlKey && objectUrls.has(row.dataset.urlKey)) {
      URL.revokeObjectURL(objectUrls.get(row.dataset.urlKey));
      objectUrls.delete(row.dataset.urlKey);
    }
    const file = fileInput.files?.[0];
    if (!file) return;
    const urlKey = `${Date.now()}_${Math.random()}`;
    const url = URL.createObjectURL(file);
    objectUrls.set(urlKey, url);
    row.dataset.urlKey = urlKey;
    row.dataset.previewUrl = url;
    previewBox.innerHTML = '';
    previewBox.classList.remove('empty');
    const img = document.createElement('img');
    img.src = url;
    img.alt = '状态预览';
    previewBox.appendChild(img);
    setPreviewFromDefault();
  });

  removeButton.addEventListener('click', () => {
    if (data.required) return;
    row.remove();
    updateStateOptions();
    setPreviewFromDefault();
  });

  row.append(nameLabel, fileLabel, previewBox, removeButton);
  return row;
}

function renderStateEditor() {
  stateEditor.innerHTML = '';
  defaultStates.forEach((state) => stateEditor.appendChild(createStateRow(state)));
  updateStateOptions();
}

function getDefaultText() {
  return form.elements.bubbleText.value || '';
}

function hidePreviewBubble() {
  window.clearTimeout(bubblePreviewTimer);
  bubble.style.display = 'none';
}

function setBubbleText(text) {
  window.clearTimeout(bubblePreviewTimer);

  if (!form.elements.bubbleEnabled.checked) {
    bubble.style.display = 'none';
    return;
  }

  const textToShow = text || getDefaultText();
  if (!textToShow) {
    bubble.style.display = 'none';
    return;
  }

  bubble.textContent = textToShow;
  bubble.style.display = 'block';
  bubblePreviewTimer = window.setTimeout(() => {
    bubble.style.display = 'none';
  }, 3000);
}

function randomItem(items) {
  if (!items || !items.length) return null;
  return items[Math.floor(Math.random() * items.length)];
}

function getInteractionsFromDom() {
  const result = {};
  triggers.forEach((trigger) => {
    const card = interactionEditor.querySelector(`[data-trigger="${trigger.key}"]`);
    const rows = Array.from(card.querySelectorAll('.interaction-row'));
    result[trigger.key] = rows.map((row) => ({
      action: row.querySelector('.action-select').value,
      text: row.querySelector('.line-input').value.trim()
    })).filter((item) => item.action);
  });
  return result;
}

function showAction(action, text = '', ms = 900) {
  const images = getImages();
  const defaultAction = defaultActionSelect.value || 'idle';
  const fallback = images[defaultAction] || images.idle;
  preview.src = images[action] || fallback || '';
  setBubbleText(text);

  window.clearTimeout(showAction.timer);
  if (ms) {
    showAction.timer = window.setTimeout(() => {
      showRestPreview(false);
    }, ms);
  }
}

function showRestPreview(showText = false) {
  const interactions = getInteractionsFromDom();
  const picked = randomItem(interactions.rest);
  const images = getImages();
  const defaultAction = defaultActionSelect.value || 'idle';
  const action = picked?.action || 'rest';
  preview.src = images[action] || images.rest || images[defaultAction] || images.idle || '';
  setBubbleText(showText ? (picked?.text || '') : '');
}

function previewTrigger(triggerKey, duration = 1000) {
  const interactions = getInteractionsFromDom();
  const picked = randomItem(interactions[triggerKey]);
  if (!picked) return;
  showAction(picked.action, picked.text, duration);
  resetRestPreviewTimer();
}

function resetRestPreviewTimer() {
  window.clearTimeout(restPreviewTimer);
  const minutes = Number(form.elements.restDelayMinutes?.value || form.elements.restDelaySeconds?.value || 8);
  restPreviewTimer = window.setTimeout(() => {
    showRestPreview(true);
    resetRestPreviewTimer();
  }, Math.max(1, minutes) * 60 * 1000);
}

function createInteractionRow(triggerKey, data = { action: 'idle', text: '' }) {
  const row = document.createElement('div');
  row.className = 'interaction-row';

  const select = document.createElement('select');
  select.className = 'action-select';

  const input = document.createElement('input');
  input.className = 'line-input';
  input.placeholder = '这条互动出现时的台词';
  input.maxLength = 120;
  input.value = data.text || '';

  const testButton = document.createElement('button');
  testButton.type = 'button';
  testButton.className = 'mini-btn';
  testButton.textContent = '预览';
  testButton.addEventListener('click', () => showAction(select.value, input.value, 1000));

  const removeButton = document.createElement('button');
  removeButton.type = 'button';
  removeButton.className = 'mini-btn ghost';
  removeButton.textContent = '删除';
  removeButton.addEventListener('click', () => {
    const rows = row.parentElement.querySelectorAll('.interaction-row');
    if (rows.length <= 1) {
      input.value = '';
      select.value = getActionList()[0] || 'idle';
      return;
    }
    row.remove();
  });

  row.append(select, input, testButton, removeButton);
  row.dataset.initialAction = data.action || 'idle';
  return row;
}

function renderInteractionEditor() {
  interactionEditor.innerHTML = '';
  triggers.forEach((trigger) => {
    const card = document.createElement('section');
    card.className = 'interaction-card';
    card.dataset.trigger = trigger.key;

    const header = document.createElement('div');
    header.className = 'interaction-head';
    header.innerHTML = `<div><h3>${trigger.title}</h3><p>${trigger.hint}</p></div>`;

    const addButton = document.createElement('button');
    addButton.type = 'button';
    addButton.className = 'add-row-btn';
    addButton.textContent = '+ 添加一条';

    const rows = document.createElement('div');
    rows.className = 'interaction-rows';
    (defaultInteractions[trigger.key] || [{ action: 'idle', text: '' }]).forEach((item) => {
      rows.appendChild(createInteractionRow(trigger.key, item));
    });

    addButton.addEventListener('click', () => {
      rows.appendChild(createInteractionRow(trigger.key, { action: getActionList()[0] || 'idle', text: '' }));
      updateStateOptions();
    });

    header.appendChild(addButton);
    card.append(header, rows);
    interactionEditor.appendChild(card);
  });

  updateStateOptions();
  interactionEditor.querySelectorAll('.interaction-row').forEach((row) => {
    const initial = row.dataset.initialAction;
    const select = row.querySelector('.action-select');
    if (getActionList().includes(initial)) select.value = initial;
  });
}

addStateBtn.addEventListener('click', () => {
  stateEditor.appendChild(createStateRow({ name: `custom_${++customStateCount}`, label: '自定义状态' }));
  updateStateOptions();
});

preview.addEventListener('mouseenter', () => previewTrigger('hover', 900));
preview.addEventListener('mouseleave', () => showAction(defaultActionSelect.value || 'idle', getDefaultText(), 0));
preview.addEventListener('click', () => {
  clearTimeout(clickTimer);
  clickTimer = setTimeout(() => previewTrigger('click', 1200), 220);
});
preview.addEventListener('dblclick', () => {
  clearTimeout(clickTimer);
  previewTrigger('doubleClick', 1400);
});

defaultActionSelect.addEventListener('change', setPreviewFromDefault);

form.elements.bubbleText.addEventListener('input', (event) => {
  setBubbleText(event.target.value || '你好呀！');
});

form.elements.bubbleEnabled.addEventListener('change', (event) => {
  if (event.target.checked) {
    setBubbleText(getDefaultText());
  } else {
    hidePreviewBubble();
  }
});

(form.elements.restDelayMinutes || form.elements.restDelaySeconds).addEventListener('input', resetRestPreviewTimer);

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  downloadLink.classList.add('hidden');
  statusEl.textContent = '正在生成，请稍等...';
  generateBtn.disabled = true;

  try {
    const states = getStatesFromDom();
    const idle = states.find((state) => state.name === 'idle');
    if (!idle || !idle.file) throw new Error('请至少上传 idle 默认状态图片。');

    const duplicateCheck = new Set();
    for (const state of states) {
      if (!state.name) throw new Error('状态名称不能为空。');
      if (duplicateCheck.has(state.name)) throw new Error(`状态名称重复：${state.name}`);
      duplicateCheck.add(state.name);
    }

    const formData = new FormData();
    formData.set('petName', form.elements.petName.value);
    formData.set('width', form.elements.width.value);
    formData.set('height', form.elements.height.value);
    formData.set('restDelayMinutes', form.elements.restDelayMinutes?.value || '8');
    formData.set('bubbleText', form.elements.bubbleText.value);
    formData.set('bubbleEnabled', form.elements.bubbleEnabled.checked ? 'true' : 'false');
    formData.set('defaultAction', defaultActionSelect.value || 'idle');
    formData.set('statesJson', JSON.stringify(states.map((state) => ({ name: state.name, index: state.index }))));
    formData.set('interactionsJson', JSON.stringify(getInteractionsFromDom()));

    states.forEach((state) => {
      if (state.file) formData.append(`stateImage_${state.index}`, state.file);
    });

    if (location.protocol === 'file:') {
      throw new Error('请不要直接双击 index.html 打开网页。请先双击 start-generator.bat，然后用 http://localhost:端口 打开。');
    }

    const apiUrl = `${location.origin}/api/generate`;
    let response;
    try {
      response = await fetch(apiUrl, {
        method: 'POST',
        body: formData
      });
    } catch (networkError) {
      throw new Error('连接本地服务失败。请确认“桌面宠物生成器服务 - 不要关闭”黑色窗口还在运行；如果窗口已关闭，请重新双击 start-generator.bat。');
    }

    const responseText = await response.text();
    let data = {};
    try {
      data = responseText ? JSON.parse(responseText) : {};
    } catch {
      throw new Error('服务返回了无法识别的内容。请查看 server-log.txt，或重启 start-generator.bat 后再试。');
    }
    if (!response.ok) throw new Error(data.message || '生成失败');

    statusEl.textContent = '生成成功！下载后解压，双击 start-pet.bat 即可运行。';
    downloadLink.href = data.downloadUrl;
    downloadLink.classList.remove('hidden');
  } catch (error) {
    statusEl.textContent = error.message || '生成失败，请检查上传图片。';
  } finally {
    generateBtn.disabled = false;
  }
});

renderStateEditor();
renderInteractionEditor();
resetRestPreviewTimer();
